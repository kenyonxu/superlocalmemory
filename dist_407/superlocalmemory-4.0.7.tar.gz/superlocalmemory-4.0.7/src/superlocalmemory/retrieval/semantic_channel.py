# Copyright (c) 2026 Varun Pratap Bhardwaj / Qualixar
# Licensed under AGPL-3.0-or-later - see LICENSE file
# Part of SuperLocalMemory V3 | https://qualixar.com | https://varunpratap.com

"""SuperLocalMemory V3 — Semantic Retrieval Channel.

Fisher-aware semantic search: uses Fisher-Rao geodesic distance when
variance data is available, falls back to cosine similarity otherwise.

The Fisher distance is meaningful when memories accumulate evidence
(repeated confirmation narrows variance). For fresh benchmark data
where all variances are identical, Fisher distance degenerates to a
monotonic transform of Euclidean distance — same ranking as cosine.

Part of Qualixar | Author: Varun Pratap Bhardwaj
License: AGPL-3.0-or-later
"""

from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:
    from superlocalmemory.storage.database import DatabaseManager
    from superlocalmemory.storage.models import AtomicFact

logger = logging.getLogger(__name__)

# Minimum variance floor to prevent division-by-zero in Fisher distance
_VARIANCE_FLOOR: float = 1e-6


class _LanceCandidateSource:
    """Adapt the promoted Lance projection to the existing candidate contract."""

    available = True

    def __init__(self, backend: Any) -> None:
        self._backend = backend

    def search(self, query_embedding: list[float], *, top_k: int, profile_id: str) -> list[tuple[str, float]]:
        return self._backend.similarity_search(
            query_embedding, top_k=top_k, profile_id=profile_id,
        )


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity in [-1, 1]. Returns 0.0 on zero vectors."""
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a < _VARIANCE_FLOOR or norm_b < _VARIANCE_FLOOR:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))


def _fisher_rao_similarity(
    mu_q: np.ndarray,
    mu_f: np.ndarray,
    var_f: np.ndarray,
    temperature: float = 15.0,
) -> float:
    """Fisher-Rao geodesic similarity on diagonal Gaussian manifold.

    d_FR^2 = sum_i [ (mu_q_i - mu_f_i)^2 / max(var_f_i, eps) ]
    similarity = exp(-d_FR^2 / temperature)

    When all variances are equal, this is equivalent to a scaled
    Euclidean distance — same ranking as cosine on normalized vectors.
    The advantage appears when variances differ across memories.
    """
    diff = mu_q - mu_f
    var_safe = np.maximum(var_f, _VARIANCE_FLOOR)
    d_sq = float(np.sum(diff * diff / var_safe))
    return math.exp(-d_sq / temperature)


class SemanticChannel:
    """Dense semantic retrieval via embedding similarity.

    Scans all facts for a profile. Uses a GRADUATED Fisher-Rao ramp:
    fresh facts (low access_count) use cosine, frequently-accessed facts
    transition to Fisher-Rao distance for uncertainty-aware similarity.

    V3.2: VectorStore KNN fast path when available, falls back to full scan.

    Graduated ramp: weight = min(1.2, access_count / 10 * 1.2)
    Final sim = fisher_weight * fisher_sim + (1 - fisher_weight) * cosine_sim
    """

    def __init__(
        self,
        db: DatabaseManager,
        fisher_temperature: float = 15.0,
        embedder: object | None = None,
        fisher_mode: str = "simplified",
        vector_store: Any | None = None,
        quantization_aware_search: Any | None = None,
    ) -> None:
        self._db = db
        self._temperature = fisher_temperature
        self._embedder = embedder
        self._fisher_mode = fisher_mode if fisher_mode in ("simplified", "full") else "simplified"
        # Lazily instantiated full metric (avoids import cost when not needed)
        self._full_metric: object | None = None
        # V3.3.26: Lazily instantiated FRQAD metric for mixed-precision scoring
        self._frqad_metric: object | None = None
        self._vector_store = vector_store
        self._scale_vector_backend: Any | None = None
        self._scale_shadow_checks = 0
        self._scale_shadow_mismatches = 0
        # V3.3.19: TurboQuant 3-tier search (stateless, optional)
        self._qas = quantization_aware_search

    def search(
        self,
        query_embedding: list[float],
        profile_id: str,
        top_k: int = 50,
        include_global: bool | None = None,
        include_shared: bool | None = None,
    ) -> list[tuple[str, float]]:
        """Search for semantically similar facts.

        Uses VectorStore KNN if available, otherwise full-table scan.
        Fisher-Rao scoring preserved as post-KNN secondary signal.

        Args:
            query_embedding: Dense vector for the query.
            profile_id: Scope to this profile.
            top_k: Maximum results to return.
            include_global: Include global-scope facts. Defaults to the
                ``include_global`` instance attribute when not supplied,
                preserving backward compatibility for callers that still
                set the attribute directly.
            include_shared: Include shared-scope facts. Same fallback.

        Returns:
            List of (fact_id, score) sorted by score descending.
            Score is in [0, 1] range.
        """
        # Resolve scope flags: explicit param takes priority; fall back to the
        # legacy attribute-based path so existing callers keep working.
        if include_global is None:
            include_global = bool(getattr(self, "include_global", False))
        if include_shared is None:
            include_shared = bool(getattr(self, "include_shared", False))

        if not query_embedding:
            return []

        q_vec = np.array(query_embedding, dtype=np.float32)

        # Lance is a derived projection.  It is never an authorization source
        # and it never silently replaces the canonical sqlite-vec path: every
        # promoted query is shadowed and falls back if the result *membership*
        # differs. Order differences within the same fact set are tolerated —
        # float-score ties would otherwise force a fallback on every query,
        # leaving the promoted backend permanently unused. Once membership
        # matches, the projected backend's own ranking is authoritative.
        if (
            self._scale_vector_backend is not None
            and not include_global
            and not include_shared
        ):
            projected = self._search_via_lance(
                query_embedding, q_vec, profile_id, top_k,
                include_global=include_global, include_shared=include_shared,
            )
            canonical = self._search_without_lance(
                query_embedding, q_vec, profile_id, top_k,
                include_global=include_global, include_shared=include_shared,
            )
            self._scale_shadow_checks += 1
            if {fid for fid, _ in projected} == {fid for fid, _ in canonical}:
                return projected
            self._scale_shadow_mismatches += 1
            logger.warning("Lance semantic projection diverged from SQLite; using SQLite")
            return canonical

        # --- FAST PATH: sqlite-vec KNN ---
        if self._vector_store and self._vector_store.available:
            results = self._search_via_vector_store(
                query_embedding, q_vec, profile_id, top_k,
                include_global=include_global, include_shared=include_shared,
            )
            if results:  # If vec0 returned results, use them
                return results
            # If vec0 is empty (cold start), fall through to full scan

        # --- FALLBACK: full-table scan (original code, unchanged) ---
        return self._search_full_scan(
            query_embedding, q_vec, profile_id, top_k,
            include_global=include_global, include_shared=include_shared,
        )

    def set_scale_vector_backend(self, backend: Any | None) -> None:
        """Attach a parity-verified Lance projection without replacing SQLite."""
        self._scale_vector_backend = backend

    def scale_projection_telemetry(self) -> dict[str, int]:
        return {
            "shadow_checks": self._scale_shadow_checks,
            "shadow_mismatches": self._scale_shadow_mismatches,
        }

    def _search_via_lance(
        self,
        query_embedding: list[float],
        q_vec: np.ndarray,
        profile_id: str,
        top_k: int,
        include_global: bool | None = None,
        include_shared: bool | None = None,
    ) -> list[tuple[str, float]]:
        if include_global is None:
            include_global = bool(getattr(self, "include_global", False))
        if include_shared is None:
            include_shared = bool(getattr(self, "include_shared", False))
        original_store, original_qas = self._vector_store, self._qas
        try:
            self._vector_store = _LanceCandidateSource(self._scale_vector_backend)
            # QAS indexes SQLite/quantized records and cannot represent Lance.
            self._qas = None
            return self._search_via_vector_store(
                query_embedding, q_vec, profile_id, top_k,
                include_global=include_global, include_shared=include_shared,
            )
        except Exception as exc:
            logger.warning("Lance semantic projection failed closed to SQLite: %s", exc)
            return []
        finally:
            self._vector_store, self._qas = original_store, original_qas

    def _search_without_lance(
        self,
        query_embedding: list[float],
        q_vec: np.ndarray,
        profile_id: str,
        top_k: int,
        include_global: bool | None = None,
        include_shared: bool | None = None,
    ) -> list[tuple[str, float]]:
        if include_global is None:
            include_global = bool(getattr(self, "include_global", False))
        if include_shared is None:
            include_shared = bool(getattr(self, "include_shared", False))
        backend, self._scale_vector_backend = self._scale_vector_backend, None
        try:
            if self._vector_store and self._vector_store.available:
                results = self._search_via_vector_store(
                    query_embedding, q_vec, profile_id, top_k,
                    include_global=include_global, include_shared=include_shared,
                )
                if results:
                    return results
            return self._search_full_scan(
                query_embedding, q_vec, profile_id, top_k,
                include_global=include_global, include_shared=include_shared,
            )
        finally:
            self._scale_vector_backend = backend

    def _search_via_vector_store(
        self,
        query_embedding: list[float],
        q_vec: np.ndarray,
        profile_id: str,
        top_k: int,
        include_global: bool | None = None,
        include_shared: bool | None = None,
    ) -> list[tuple[str, float]]:
        """KNN via VectorStore (or QAS 3-tier), then Fisher-Rao re-scoring."""
        if include_global is None:
            include_global = bool(getattr(self, "include_global", False))
        if include_shared is None:
            include_shared = bool(getattr(self, "include_shared", False))
        # V3.3.19: Try TurboQuant 3-tier search first (float32 + int8 + polar)
        if self._qas is not None:
            try:
                knn_results = self._qas.search(
                    query_embedding=q_vec, profile_id=profile_id,
                    top_k=top_k * 2,
                )
            except Exception:
                knn_results = []
            # Fall through to VectorStore if QAS returned nothing
            if not knn_results:
                knn_results = self._vector_store.search(
                    query_embedding, top_k=top_k * 2, profile_id=profile_id,
                )
        else:
            # Step 1: Fast KNN -- get 2x top_k candidates for Fisher re-ranking
            knn_results = self._vector_store.search(
                query_embedding, top_k=top_k * 2, profile_id=profile_id,
            )

        # M-01: Normalize KNN scores to [0.5, 1.0] via (score + 1.0) / 2.0 so
        # they are on the same scale as full-scan scores computed from
        # (_cosine_similarity(q, f) + 1.0) / 2.0 in the external_scores path.
        # vector_store.search() clips at 0 (max(0, cosine)), which maps [–1,1]
        # to [0,1]; the canonical formula maps to [0.5, 1.0] for positives.
        # Both are [0,1] but different scales — without this normalization KNN
        # scores are systematically lower and external facts always win max().
        knn_results = [(fid, (score + 1.0) / 2.0) for fid, score in knn_results]

        # The vector index is partitioned by owner profile. An opted-in global
        # or authorized shared fact owned by another profile cannot enter the
        # local KNN candidate set, so merge the bounded cross-profile visible
        # supplement using the same canonical DB scope predicate as fallback.
        external_facts = self._db.get_external_visible_facts(
            profile_id,
            include_global=include_global,
            include_shared=include_shared,
        )
        external_scores: list[tuple[str, float]] = []
        for fact in external_facts:
            if fact.embedding is None:
                continue
            fact_vec = np.array(fact.embedding, dtype=np.float32)
            if fact_vec.shape != q_vec.shape:
                continue
            score = (_cosine_similarity(q_vec, fact_vec) + 1.0) / 2.0
            if score > 0.05:
                external_scores.append((fact.fact_id, score))

        if external_scores:
            combined = {fid: score for fid, score in knn_results}
            for fact_id, score in external_scores:
                combined[fact_id] = max(combined.get(fact_id, 0.0), score)
            knn_results = sorted(
                combined.items(), key=lambda item: item[1], reverse=True,
            )[:top_k * 2]
        if not knn_results:
            return []  # Caller falls through to full scan

        # Step 2: Load only the candidate facts (NOT all facts)
        candidate_ids = [fid for fid, _ in knn_results]
        knn_scores = {fid: score for fid, score in knn_results}
        facts = self._db.get_facts_by_ids(
            candidate_ids, profile_id,
            include_global=include_global,
            include_shared=include_shared,
        )

        if not facts:
            # The vector/QAS indexes are candidate sources, never an
            # authorization source.  Returning their raw IDs here leaked an
            # owner-private fact precisely when canonical scope filtering
            # rejected the entire candidate set.  Empty means "no authorized
            # fast-path hits" so the caller may use the scoped full scan.
            return []

        # Step 3: Fisher-Rao re-scoring on the subset
        q_mean: np.ndarray | None = None
        q_var: np.ndarray | None = None
        if self._embedder and hasattr(self._embedder, 'compute_fisher_params'):
            qm, qv = self._embedder.compute_fisher_params(query_embedding)
            q_mean = np.array(qm, dtype=np.float32)
            q_var = np.array(qv, dtype=np.float32)

        scored: list[tuple[str, float]] = []
        for fact in facts:
            # C2-ret H-01: recompute the final cosine from the canonical
            # full-precision embedding using the SAME formula as the full-scan
            # fallback, so the fast path is observationally equivalent — identical
            # score MAGNITUDES, not merely identical rankings. The KNN/vector-store
            # score is a candidate-SELECTION signal only (it decides which facts
            # are Fisher-rescored), never the final magnitude; trusting it here
            # leaked the vector store's negative-cosine clamp into public scores.
            # When a candidate carries no usable embedding (index-only rows), fall
            # back to the normalized KNN score, preserving the M-01 contract.
            f_vec: np.ndarray | None = None
            if fact.embedding is not None:
                candidate = np.array(fact.embedding, dtype=np.float32)
                if candidate.shape == q_vec.shape:
                    f_vec = candidate

            if f_vec is not None:
                cos_sim = (_cosine_similarity(q_vec, f_vec) + 1.0) / 2.0
            else:
                cos_sim = knn_scores.get(fact.fact_id, 0.0)

            fisher_weight = self._fisher_weight(fact.access_count)

            if (fisher_weight > 0.01
                    and fact.fisher_variance is not None
                    and f_vec is not None
                    and len(fact.fisher_variance) == len(q_vec)):
                var_vec = np.array(fact.fisher_variance, dtype=np.float32)
                f_sim = self._compute_fisher_sim(
                    q_vec, f_vec, var_vec, fact, q_mean, q_var,
                )
                sim = fisher_weight * f_sim + (1.0 - fisher_weight) * cos_sim
            else:
                sim = cos_sim

            if sim > 0.05:
                scored.append((fact.fact_id, sim))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def _search_full_scan(
        self,
        query_embedding: list[float],
        q_vec: np.ndarray,
        profile_id: str,
        top_k: int,
        include_global: bool | None = None,
        include_shared: bool | None = None,
    ) -> list[tuple[str, float]]:
        """Original full-table-scan search. Used as fallback when VectorStore
        is unavailable or empty (cold start).
        """
        if include_global is None:
            include_global = bool(getattr(self, "include_global", False))
        if include_shared is None:
            include_shared = bool(getattr(self, "include_shared", False))
        # Compute query Fisher params for Bayesian comparison (F45 fix)
        q_mean: np.ndarray | None = None
        q_var: np.ndarray | None = None
        if self._embedder and hasattr(self._embedder, 'compute_fisher_params'):
            qm, qv = self._embedder.compute_fisher_params(query_embedding)
            q_mean = np.array(qm, dtype=np.float32)
            q_var = np.array(qv, dtype=np.float32)

        facts = self._db.get_all_facts(
            profile_id,
            include_global=include_global,
            include_shared=include_shared,
        )

        scored: list[tuple[str, float]] = []
        for fact in facts:
            if fact.embedding is None:
                continue

            f_vec = np.array(fact.embedding, dtype=np.float32)
            if f_vec.shape != q_vec.shape:
                continue

            # Cosine baseline (always computed)
            cos_sim = (_cosine_similarity(q_vec, f_vec) + 1.0) / 2.0

            # The weighting contract is identical to the sqlite-vec path.
            fisher_weight = self._fisher_weight(fact.access_count)

            if (fisher_weight > 0.01
                    and fact.fisher_variance is not None
                    and len(fact.fisher_variance) == len(q_vec)):
                var_vec = np.array(fact.fisher_variance, dtype=np.float32)
                f_sim = self._compute_fisher_sim(
                    q_vec, f_vec, var_vec, fact, q_mean, q_var,
                )
                sim = fisher_weight * f_sim + (1.0 - fisher_weight) * cos_sim
            else:
                sim = cos_sim

            if sim > 0.05:
                scored.append((fact.fact_id, sim))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    @staticmethod
    def _fisher_weight(access_count: int | None) -> float:
        """Canonical Fisher blend shared by every semantic candidate path."""
        graduated = (access_count or 0) / 10.0 * 1.2
        # A small floor keeps Fisher variance active for new facts.  The cap
        # prevents the blend from extrapolating beyond its two score inputs.
        return min(1.0, max(0.15, graduated))

    # ------------------------------------------------------------------
    # Fisher similarity dispatch
    # ------------------------------------------------------------------

    def _compute_fisher_sim(
        self,
        q_vec: np.ndarray,
        f_vec: np.ndarray,
        var_vec: np.ndarray,
        fact: AtomicFact,
        q_mean: np.ndarray | None,
        q_var: np.ndarray | None,
    ) -> float:
        """Compute Fisher-Rao similarity using simplified, full, or FRQAD metric.

        Simplified (default): Mahalanobis-like distance using only fact variance.
        Full: Atkinson-Mitchell geodesic via FisherRaoMetric.similarity().
        FRQAD: V3.3.26 — quantization-aware distance via FRQADMetric when
               the fact has a non-32-bit embedding (mixed precision).

        Falls back to simplified if full/FRQAD cannot be applied.
        """
        # V3.3.26: FRQAD for mixed-precision facts
        fact_bw = getattr(fact, "bit_width", 32) or 32
        if fact_bw < 32 and q_mean is not None and q_var is not None:
            return self._compute_frqad_sim(
                q_mean, q_var, 32, f_vec, var_vec, fact_bw, fact,
            )

        if self._fisher_mode == "full":
            return self._compute_full_fisher_sim(
                q_vec, f_vec, var_vec, fact, q_mean, q_var,
            )
        return _fisher_rao_similarity(q_vec, f_vec, var_vec, self._temperature)

    def _compute_frqad_sim(
        self,
        q_mean: np.ndarray,
        q_var: np.ndarray,
        q_bw: int,
        f_mean: np.ndarray,
        f_var: np.ndarray,
        f_bw: int,
        fact: AtomicFact,
    ) -> float:
        """FRQAD: quantization-aware Fisher-Rao similarity (Paper 3, C1).

        Uses variance inflation: sigma_eff = sigma * (32/bw)^kappa
        to penalize lower-precision embeddings on the statistical manifold.
        """
        frqad = self._get_frqad_metric()
        if frqad is None:
            return _fisher_rao_similarity(q_mean, f_mean, f_var, self._temperature)
        try:
            return frqad.similarity(
                q_mean, q_var, q_bw,
                f_mean, f_var, f_bw,
            )
        except (ValueError, FloatingPointError):
            logger.debug("FRQAD raised; falling back to simplified Fisher-Rao")
            return _fisher_rao_similarity(q_mean, f_mean, f_var, self._temperature)

    def _get_frqad_metric(self) -> object | None:
        """Lazy-load FRQADMetric to avoid import-time cost."""
        if self._frqad_metric is None:
            try:
                from superlocalmemory.math.fisher import FisherRaoMetric
                from superlocalmemory.math.fisher_quantized import FRQADConfig, FRQADMetric
                base = FisherRaoMetric(temperature=self._temperature)
                self._frqad_metric = FRQADMetric(base, FRQADConfig())
            except Exception:
                logger.debug("FRQAD metric unavailable; mixed-precision scoring disabled")
                return None
        return self._frqad_metric

    def _compute_full_fisher_sim(
        self,
        q_vec: np.ndarray,
        f_vec: np.ndarray,
        var_vec: np.ndarray,
        fact: AtomicFact,
        q_mean: np.ndarray | None,
        q_var: np.ndarray | None,
    ) -> float:
        """Full Atkinson-Mitchell geodesic via FisherRaoMetric.

        Requires fisher_mean on the fact AND query variance. If either is
        missing, falls back to the simplified local computation so that
        the graduated ramp still produces a score.
        """
        # Need fact fisher_mean for the full metric
        fact_mean = fact.fisher_mean
        if fact_mean is None or len(fact_mean) != len(f_vec):
            # No stored mean — fall back to simplified
            return _fisher_rao_similarity(q_vec, f_vec, var_vec, self._temperature)

        # Need query variance for the full metric
        if q_mean is None or q_var is None:
            return _fisher_rao_similarity(q_vec, f_vec, var_vec, self._temperature)

        if len(q_mean) != len(fact_mean) or len(q_var) != len(var_vec):
            return _fisher_rao_similarity(q_vec, f_vec, var_vec, self._temperature)

        metric = self._get_full_metric()
        try:
            return metric.similarity(
                q_mean.tolist(), q_var.tolist(),
                list(fact_mean), list(var_vec),
            )
        except (ValueError, FloatingPointError):
            # Numerical issue — fall back gracefully
            logger.debug("Full Fisher metric raised; falling back to simplified")
            return _fisher_rao_similarity(q_vec, f_vec, var_vec, self._temperature)

    def _get_full_metric(self) -> "FisherRaoMetric":  # noqa: F821
        """Lazy-load FisherRaoMetric to avoid import-time cost."""
        if self._full_metric is None:
            from superlocalmemory.math.fisher import FisherRaoMetric
            self._full_metric = FisherRaoMetric(temperature=self._temperature)
        return self._full_metric  # type: ignore[return-value]
