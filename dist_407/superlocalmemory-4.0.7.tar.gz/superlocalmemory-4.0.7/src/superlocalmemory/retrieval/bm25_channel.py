# Copyright (c) 2026 Varun Pratap Bhardwaj / Qualixar
# Licensed under AGPL-3.0-or-later - see LICENSE file
# Part of SuperLocalMemory V3 | https://qualixar.com | https://varunpratap.com

"""SuperLocalMemory V3 — BM25 Keyword Search Channel.

Persistent BM25Plus index over fact content. Catches exact name/date
matches that embedding similarity misses.

V1 bug fix: V1 kept BM25 tokens in-memory only — a restart lost
the entire index. This version persists tokens to the DB via
store_bm25_tokens / get_all_bm25_tokens and cold-loads on init.

Part of Qualixar | Author: Varun Pratap Bhardwaj
License: AGPL-3.0-or-later
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

from rank_bm25 import BM25Plus

from superlocalmemory.storage.database import _scope_where

if TYPE_CHECKING:
    from superlocalmemory.storage.database import DatabaseManager

logger = logging.getLogger(__name__)

# Minimal stopwords — small set to avoid stripping important terms
_STOPWORDS: frozenset[str] = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "shall",
    "should", "may", "might", "must", "can", "could", "of", "in", "to",
    "for", "with", "on", "at", "from", "by", "as", "into", "through",
    "and", "but", "or", "nor", "not", "so", "yet", "if", "then", "than",
    "that", "this", "it", "its", "i", "me", "my", "we", "our", "you",
    "your", "he", "him", "his", "she", "her", "they", "them", "their",
})

# Token pattern: words with letters/digits, keeps hyphens and apostrophes
_TOKEN_RE = re.compile(r"[a-zA-Z0-9][\w'-]*[a-zA-Z0-9]|[a-zA-Z0-9]")


def tokenize(text: str) -> list[str]:
    """Tokenize text: lowercase, split, remove stopwords.

    Exported so encoding pipeline can persist tokens at ingest time.
    """
    tokens = _TOKEN_RE.findall(text.lower())
    return [t for t in tokens if t not in _STOPWORDS]


class BM25Channel:
    """Persistent BM25Plus index for keyword retrieval.

    On cold start, loads all tokens from the DB. After that, new facts
    are added incrementally. The BM25Plus model is rebuilt lazily
    before each search when the corpus has changed.

    Attributes:
        document_count: Number of indexed documents.
    """

    def __init__(self, db: DatabaseManager) -> None:
        self._db = db
        self._corpus: list[list[str]] = []
        self._fact_ids: list[str] = []
        self._fact_id_set: set[str] = set()
        self._raw_texts: list[str] = []  # V3.3.12: raw content for phrase matching
        self._bm25: BM25Plus | None = None
        self._dirty: bool = False
        self._loaded_profiles: set[str] = set()
        self._loaded_scope_key: tuple[str, bool, bool] | None = None

    @property
    def document_count(self) -> int:
        return len(self._corpus)

    def ensure_loaded(
        self,
        profile_id: str,
        include_global: bool | None = None,
        include_shared: bool | None = None,
    ) -> None:
        """Cold-load BM25 tokens from DB for a profile (once).

        Idempotent: subsequent calls for the same profile/scope are no-ops.

        Args:
            profile_id: Profile to load.
            include_global: Include global-scope facts. Falls back to the
                instance attribute when not supplied.
            include_shared: Include shared-scope facts. Same fallback.
        """
        if include_global is None:
            include_global = bool(getattr(self, "include_global", False))
        if include_shared is None:
            include_shared = bool(getattr(self, "include_shared", False))
        scope_key = (profile_id, include_global, include_shared)
        if scope_key == self._loaded_scope_key:
            return

        # A legacy in-memory index is a visibility-specific view. Reusing a
        # corpus warmed under another profile/scope leaks private documents or
        # omits newly enabled global/shared documents.
        self._corpus = []
        self._fact_ids = []
        self._fact_id_set = set()
        self._raw_texts = []
        self._bm25 = None
        token_map = self._db.get_all_bm25_tokens(
            profile_id,
            include_global=include_global,
            include_shared=include_shared,
        )
        if not token_map:
            # Fallback: tokenize facts directly if no pre-stored tokens
            facts = self._db.get_all_facts(
                profile_id,
                include_global=include_global,
                include_shared=include_shared,
            )
            for fact in facts:
                if fact.fact_id in self._fact_id_set:
                    continue
                tokens = tokenize(fact.content)
                if tokens:
                    self._corpus.append(tokens)
                    self._fact_ids.append(fact.fact_id)
                    self._fact_id_set.add(fact.fact_id)
                    self._raw_texts.append(fact.content)
                    # Persist for next cold start
                    self._db.store_bm25_tokens(fact.fact_id, profile_id, tokens)
        else:
            # Load raw texts for phrase matching (V3.3.12)
            fact_content_map = {}
            try:
                facts = self._db.get_all_facts(
                    profile_id,
                    include_global=include_global,
                    include_shared=include_shared,
                )
                fact_content_map = {f.fact_id: f.content for f in facts}
            except Exception:
                pass
            for fid, tokens in token_map.items():
                if fid in self._fact_id_set:
                    continue
                self._corpus.append(tokens)
                self._fact_ids.append(fid)
                self._fact_id_set.add(fid)
                self._raw_texts.append(fact_content_map.get(fid, ""))

        self._dirty = True
        self._loaded_profiles.add(profile_id)
        self._loaded_scope_key = scope_key
        logger.debug(
            "BM25 cold-loaded %d documents for profile=%s",
            len(token_map) if token_map else 0, profile_id,
        )

    def add(self, fact_id: str, content: str, profile_id: str) -> None:
        """Add a single fact to the index and persist tokens.

        Args:
            fact_id: Unique fact identifier.
            content: Raw text content to index.
            profile_id: Owner profile.
        """
        tokens = tokenize(content)
        if not tokens:
            return

        self._corpus.append(tokens)
        self._fact_ids.append(fact_id)
        self._fact_id_set.add(fact_id)
        if not hasattr(self, '_raw_texts'):
            self._raw_texts = []
        self._raw_texts.append(content)
        self._dirty = True

        # Persist for cold start
        self._db.store_bm25_tokens(fact_id, profile_id, tokens)

    def _fts5_search(
        self,
        query: str,
        profile_id: str,
        top_k: int = 30,
        include_global: bool | None = None,
        include_shared: bool | None = None,
    ) -> list[tuple[str, float]]:
        """v3.5.0: SQLite FTS5 keyword search (C-level indexed, scales to millions).

        Uses the ``atomic_facts_fts`` external-content FTS5 table (kept in sync
        by INSERT/DELETE/UPDATE triggers). Joins ``atomic_facts`` for profile
        scoping (FTS table has no profile_id). ``bm25()`` returns a negative
        score (lower = better match); we negate it to the channel's
        "higher = better" convention. Returns [] on no matches.

        Raises (OperationalError) if the FTS5 table is absent — the caller
        then falls back to the legacy in-memory rank_bm25 path.
        """
        if include_global is None:
            include_global = bool(getattr(self, "include_global", False))
        if include_shared is None:
            include_shared = bool(getattr(self, "include_shared", False))
        tokens = tokenize(query)
        if not tokens:
            return []
        # Quote each token so query punctuation can't break FTS5 MATCH syntax;
        # OR-join for high recall (any token may match).
        match_expr = " OR ".join('"' + t.replace('"', "") + '"' for t in tokens)
        where, params = _scope_where(
            profile_id,
            include_global=include_global,
            include_shared=include_shared,
            prefix="af",
        )
        # Archived facts are not live; never surface them in keyword recall.
        # Guarded on column presence: the archive column is added by a deferred
        # migration and may be absent on an unmigrated database.
        archive_clause = (
            " AND COALESCE(af.archive_status, 'live') != 'archived'"
            if self._db._has_archive_status()
            else ""
        )
        sql = (
            "SELECT af.fact_id AS fact_id, bm25(atomic_facts_fts) AS rank "
            "FROM atomic_facts_fts "
            "JOIN atomic_facts af ON af.rowid = atomic_facts_fts.rowid "
            f"WHERE atomic_facts_fts MATCH ? AND {where}{archive_clause} "
            "ORDER BY rank LIMIT ?"
        )
        rows = self._db.execute(sql, (match_expr, *params, int(top_k)))
        out: list[tuple[str, float]] = []
        for r in rows:
            d = dict(r)
            fid = d.get("fact_id")
            if not fid:
                continue
            out.append((fid, -float(d.get("rank", 0.0))))

        # T3b: UNION fact-expansion (alias / paraphrase) matches so a query for
        # a synonym matches a fact that only used the canonical term. Additive —
        # direct content hits stay primary; an alias-only hit is added at a
        # discount so it ranks below content matches. Fail-open if the expansion
        # FTS is absent (legacy DB).
        content_ids = {fid for fid, _ in out}
        try:
            exp_sql = (
                "SELECT af.fact_id AS fact_id, bm25(fact_expansion_fts) AS rank "
                "FROM fact_expansion_fts "
                "JOIN atomic_facts af ON af.fact_id = fact_expansion_fts.fact_id "
                f"WHERE fact_expansion_fts MATCH ? AND {where}{archive_clause} "
                "ORDER BY rank LIMIT ?"
            )
            for r in self._db.execute(exp_sql, (match_expr, *params, int(top_k))):
                d = dict(r)
                fid = d.get("fact_id")
                if fid and fid not in content_ids:
                    out.append((fid, -float(d.get("rank", 0.0)) * 0.85))
        except Exception as exc:  # pragma: no cover — legacy/missing expansion FTS
            logger.debug("Expansion FTS search skipped: %s", exc)

        out.sort(key=lambda x: x[1], reverse=True)
        return out[:top_k]

    def search(
        self,
        query: str,
        profile_id: str,
        top_k: int = 30,
        include_global: bool | None = None,
        include_shared: bool | None = None,
    ) -> list[tuple[str, float]]:
        """Search BM25 index for matching facts.

        Auto-loads from DB on first call for this profile.

        Args:
            query: Search query text.
            profile_id: Scope to this profile.
            top_k: Maximum results.
            include_global: Include global-scope facts. Falls back to the
                instance attribute when not supplied.
            include_shared: Include shared-scope facts. Same fallback.

        Returns:
            List of (fact_id, bm25_score) sorted by score descending.
        """
        if include_global is None:
            include_global = bool(getattr(self, "include_global", False))
        if include_shared is None:
            include_shared = bool(getattr(self, "include_shared", False))
        # v3.5.0: FTS5 fast path — C-level indexed, ~ms, scales to millions.
        # The legacy in-memory rank_bm25 path rebuilt the whole index over the
        # entire corpus on every corpus change (11s+ at 17.5k facts, does not
        # scale). FTS5 (atomic_facts_fts, kept in sync by triggers) replaces it.
        # Falls back to rank_bm25 ONLY if the FTS5 table is genuinely
        # unavailable (raises) — e.g. a pre-FTS legacy DB.
        try:
            return self._fts5_search(
                query, profile_id, top_k,
                include_global=include_global, include_shared=include_shared,
            )
        except Exception as exc:  # pragma: no cover — legacy/missing FTS table
            logger.debug(
                "BM25 FTS5 path unavailable, using rank_bm25 fallback: %s", exc,
            )

        self.ensure_loaded(profile_id, include_global=include_global, include_shared=include_shared)

        if not self._corpus:
            return []

        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        # Rebuild BM25 model if corpus changed
        if self._dirty or self._bm25 is None:
            self._bm25 = BM25Plus(self._corpus, k1=1.2, b=0.75)
            self._dirty = False

        scores = self._bm25.get_scores(query_tokens)

        scored: list[tuple[str, float]] = []
        # V3.3.12: Exact phrase bonus — boost facts containing the full query phrase
        query_lower = query.lower().strip()
        for i, score in enumerate(scores):
            if score > 0.0:
                bonus = score
                # Exact phrase match bonus: if the query appears as a substring in the document
                if len(query_lower) >= 5 and i < len(self._raw_texts):
                    if query_lower in self._raw_texts[i].lower():
                        bonus *= 1.5  # 50% boost for exact phrase match
                scored.append((self._fact_ids[i], bonus))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def update_fact(self, fact_id: str, new_content: str, profile_id: str) -> None:
        """Replace a fact's representation in the live index and persist new tokens.

        Removes any existing in-memory entry for the fact_id first so the index
        holds each fact exactly once after the call. Delegates to remove_fact +
        add so the two operations stay in sync.

        Args:
            fact_id: Fact whose content has changed.
            new_content: Updated text to index.
            profile_id: Owner profile (used for DB token persistence).
        """
        self.remove_fact(fact_id)
        self.add(fact_id, new_content, profile_id)

    def remove_fact(self, fact_id: str) -> None:
        """Remove a fact from the live in-memory index.

        Idempotent: a no-op when the fact is not in the index. Does NOT touch
        the persistent ``bm25_tokens`` DB table — the caller is responsible for
        that (so a delete path can clean up storage independently).

        Args:
            fact_id: Fact to evict from the in-memory corpus.
        """
        if fact_id not in self._fact_id_set:
            return
        try:
            idx = self._fact_ids.index(fact_id)
            del self._corpus[idx]
            del self._fact_ids[idx]
            raw_texts = getattr(self, "_raw_texts", [])
            if idx < len(raw_texts):
                del raw_texts[idx]
            self._fact_id_set.discard(fact_id)
            self._dirty = True
        except (ValueError, IndexError):
            self._fact_id_set.discard(fact_id)

    def clear(self) -> None:
        """Clear the in-memory index (does NOT delete DB tokens)."""
        self._corpus = []
        self._fact_ids = []
        self._fact_id_set = set()
        self._bm25 = None
        self._dirty = False
        self._loaded_profiles = set()
        self._loaded_scope_key = None
