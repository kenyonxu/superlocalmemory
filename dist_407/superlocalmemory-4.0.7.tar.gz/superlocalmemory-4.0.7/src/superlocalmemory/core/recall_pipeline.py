# Copyright (c) 2026 Varun Pratap Bhardwaj / Qualixar
# Licensed under AGPL-3.0-or-later - see LICENSE file
# Part of SuperLocalMemory V3 | https://qualixar.com | https://varunpratap.com

"""Recall pipeline — extracted free functions for MemoryEngine.recall().

Direction: engine.py imports this module. This module NEVER imports engine.py.

Part of Qualixar | Author: Varun Pratap Bhardwaj
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import sqlite3
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import os

    from superlocalmemory.core.config import SLMConfig
    from superlocalmemory.core.hooks import HookRegistry
    from superlocalmemory.storage.database import DatabaseManager

from superlocalmemory.core.security_primitives import ensure_install_token
from superlocalmemory.storage.models import Mode, RecallResponse

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# LLD-00 §3 — HMAC fact-id markers (P0.4, SEC-C-01 fix)
# ---------------------------------------------------------------------------
#
# Every fact surfaced in a recall response is tagged with
#   slm:fact:<fact_id>:<hmac8>
# where hmac8 is the first 8 hex chars of HMAC-SHA256(install_token, fact_id).
#
# post_tool_outcome_hook (LLD-09) scans only for this prefix and validates
# the HMAC. Unverified markers are ignored — this closes the tool-output
# injection attack where attacker-controlled output could forge engagement
# signals by spelling a known fact_id.

_HMAC_MARKER_PREFIX = "slm:fact:"
_HMAC_LEN = 8


def _emit_marker(fact_id: str) -> str:
    """Tag ``fact_id`` with its HMAC so downstream hooks can validate.

    Deterministic per install: a given (install_token, fact_id) pair always
    produces the same marker. Token rotation invalidates old markers.
    """
    token = ensure_install_token()
    digest = hmac.new(
        token.encode("utf-8"), fact_id.encode("utf-8"), hashlib.sha256
    ).hexdigest()[:_HMAC_LEN]
    return f"{_HMAC_MARKER_PREFIX}{fact_id}:{digest}"


def _validate_marker(marker: str) -> str | None:
    """Return ``fact_id`` if ``marker`` is a valid HMAC marker, else None.

    Uses constant-time compare. Never raises.
    """
    if not isinstance(marker, str) or not marker.startswith(_HMAC_MARKER_PREFIX):
        return None
    rest = marker[len(_HMAC_MARKER_PREFIX):]
    fact_id, sep, presented = rest.rpartition(":")
    if not sep or not fact_id or len(presented) != _HMAC_LEN:
        return None
    try:
        token = ensure_install_token()
    except Exception:  # pragma: no cover — install-token I/O failure
        return None
    expected = hmac.new(
        token.encode("utf-8"), fact_id.encode("utf-8"), hashlib.sha256
    ).hexdigest()[:_HMAC_LEN]
    if hmac.compare_digest(presented, expected):
        return fact_id
    return None


def _apply_markers_to_response(response: RecallResponse) -> None:
    """Populate ``result.marker`` on every result in ``response``, in place.

    Called as the last step of :func:`run_recall` before returning. Empty
    responses pass through untouched.

    # L-P-06: audit flagged ``dataclasses.replace`` as a cheaper path.
    # Verified: ``RecallResult`` is NOT frozen, so the direct in-place
    # attribute assignment below is the O(1) mutation path — no dataclass
    # reconstruction happens. ``replace`` would ALLOCATE a fresh instance
    # per result (strictly slower). Keep the in-place mutation.
    """
    for r in response.results:
        r.marker = _emit_marker(r.fact.fact_id)


def _preserve_exact_lexical_evidence(
    response: RecallResponse,
    query: str,
) -> None:
    """Keep a deterministic exact BM25 hit ahead of learned refinements.

    Adaptive and bandit ranking are valuable for ambiguous candidates, but
    they must not demote a fact containing the caller's exact query behind
    semantically similar noise. This guard runs after every learned layer and
    changes only ordering; it does not introduce or bypass evidence.
    """
    normalized_query = " ".join(query.casefold().split())
    if len(normalized_query) < 3 or len(response.results) < 2:
        return
    exact = [
        result
        for result in response.results
        if (
            float((result.channel_scores or {}).get("bm25", 0.0) or 0.0) > 0.0
            and normalized_query
            in " ".join(result.fact.content.casefold().split())
        )
    ]
    if not exact:
        return
    strongest = max(
        exact,
        key=lambda result: float(
            (result.channel_scores or {}).get("bm25", 0.0) or 0.0,
        ),
    )
    if response.results[0] is strongest:
        return
    response.results = [
        strongest,
        *(result for result in response.results if result is not strongest),
    ]


# ---------------------------------------------------------------------------
# Stage 8 SB-1 — feed shadow_router from recall-settled signals.
#
# LLD-10 Track A.3 needs live-recall A/B observations to feed ShadowTest
# (pre-promotion) and ModelRollback (post-promotion). The ndcg_at_10
# signal materialises when ``EngagementRewardModel.finalize_outcome``
# settles a row — that is the natural call site for this helper.
#
# This is a THIN wrapper over ``core.shadow_router.get_shadow_router``
# so the finalize-outcome path does not need to import shadow_router
# directly. Fail-soft on every error — recall pipeline integrity comes
# first.
# ---------------------------------------------------------------------------


def feed_recall_settled(
    *,
    memory_db: str,
    learning_db: str,
    profile_id: str,
    query_id: str,
    ndcg_at_10: float,
) -> None:
    """Route a settled recall's NDCG@10 into the shadow router.

    The arm is recomputed from ``query_id`` so callers don't need to
    persist arm assignment anywhere — the router's determinism
    guarantees the same arm decision at settle-time that was used at
    recall-time.

    Called from ``EngagementRewardModel.finalize_outcome`` (LLD-08 §4.2)
    after the reward row is committed. Cheap on the hot path: one
    singleton-cache read + one paired-list append.
    """
    try:
        from superlocalmemory.core import shadow_router as _sr
        router = _sr.get_shadow_router(
            memory_db=memory_db,
            learning_db=learning_db,
            profile_id=profile_id,
        )
        arm = router.route_query(query_id)
        router.on_recall_settled(
            query_id=query_id, arm=arm, ndcg_at_10=float(ndcg_at_10),
        )
    except Exception as exc:  # pragma: no cover — defence in depth
        logger.debug("feed_recall_settled error: %s", exc)


# ---------------------------------------------------------------------------
# V3.3.16: Module-level singletons for recall hot-path objects.
# Prevents creating new BehavioralTracker / ForgettingScheduler per recall
# (304 recalls = 304 objects that fragment pymalloc arenas → 25GB).
# ---------------------------------------------------------------------------

_behavioral_tracker_cache: dict[int, object] = {}
_forgetting_scheduler_cache: dict[int, object] = {}


def _get_behavioral_tracker(db: Any) -> Any:
    """Get or create a cached BehavioralTracker for this DB instance."""
    key = id(db)
    if key not in _behavioral_tracker_cache:
        from superlocalmemory.learning.behavioral import BehavioralTracker
        _behavioral_tracker_cache[key] = BehavioralTracker(db)
    return _behavioral_tracker_cache[key]


def _get_forgetting_scheduler(db: Any, config: Any) -> Any:
    """Get or create a cached ForgettingScheduler for this DB instance."""
    key = id(db)
    if key not in _forgetting_scheduler_cache:
        from superlocalmemory.learning.forgetting_scheduler import ForgettingScheduler
        from superlocalmemory.math.ebbinghaus import EbbinghausCurve
        ebbinghaus = EbbinghausCurve(config.forgetting)
        _forgetting_scheduler_cache[key] = ForgettingScheduler(db, ebbinghaus, config.forgetting)
    return _forgetting_scheduler_cache[key]


def release_recall_resources(db: Any) -> None:
    """Release process-level recall singletons owned by a closing database."""
    key = id(db)
    _behavioral_tracker_cache.pop(key, None)
    _forgetting_scheduler_cache.pop(key, None)


def _behavioral_entities(results: list[Any], limit: int = 20) -> list[str]:
    """Read canonical entity IDs from the typed retrieval-result contract.

    ``RetrievalResult`` is a dataclass whose entity evidence lives on
    ``result.fact.canonical_entities``. Treating it as a SQLite mapping silently
    discarded every entity and disabled behavioral entity learning.
    """
    entities: list[str] = []
    seen: set[str] = set()
    for result in results:
        fact = getattr(result, "fact", None)
        for entity_id in getattr(fact, "canonical_entities", ()) or ():
            if not isinstance(entity_id, str) or not entity_id or entity_id in seen:
                continue
            seen.add(entity_id)
            entities.append(entity_id)
            if len(entities) >= limit:
                return entities
    return entities


# ---------------------------------------------------------------------------
# S8-ARC-04 (v3.4.22): unified ranking entry point.
# ---------------------------------------------------------------------------

_RANKING_MODES: frozenset[str] = frozenset({"off", "v1", "v2", "v2-ensemble"})


class _ReadOnlyLearningView:
    """Minimal learning-model reader that cannot initialise or mutate a DB."""

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path.resolve()

    def _connection(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            f"{self._db_path.as_uri()}?mode=ro",
            uri=True,
            timeout=0.25,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only=ON")
        connection.execute("PRAGMA busy_timeout=250")
        return connection

    def count_signals(self, profile_id: str) -> int:
        connection = self._connection()
        try:
            row = connection.execute(
                "SELECT COUNT(*) AS count FROM learning_signals "
                "WHERE profile_id = ?",
                (profile_id,),
            ).fetchone()
            return int(row["count"]) if row else 0
        finally:
            connection.close()

    def count_feedback(self, profile_id: str) -> int:
        """Count legacy feedback without running schema initialization.

        Reports the raw ``learning_feedback`` table, which the dashboard
        surfaces as ``legacy_feedback_rows`` alongside a pending-migration
        card. Do NOT gate a ranking phase on this — use ``count_signals``,
        which is the counter every other surface resolves its phase from
        (issue #106).
        """
        connection = self._connection()
        try:
            row = connection.execute(
                "SELECT COUNT(*) AS count FROM learning_feedback "
                "WHERE profile_id = ?",
                (profile_id,),
            ).fetchone()
            return int(row["count"]) if row else 0
        finally:
            connection.close()

    def load_active_model(self, profile_id: str) -> dict[str, Any] | None:
        connection = self._connection()
        try:
            row = connection.execute(
                "SELECT state_bytes, bytes_sha256, feature_names, trained_at, "
                "model_version FROM learning_model_state "
                "WHERE profile_id = ? AND is_active = 1 LIMIT 1",
                (profile_id,),
            ).fetchone()
            if row is None:
                return None
            return {
                "state_bytes": bytes(row["state_bytes"]),
                "bytes_sha256": row["bytes_sha256"],
                "feature_names": row["feature_names"],
                "trained_at": row["trained_at"],
                "model_version": row["model_version"],
            }
        finally:
            connection.close()


def _resolve_ranking_mode(env: "dict[str, str] | os._Environ[str]") -> str:
    """Map the ``SLM_RANKING`` env var to a canonical mode.

    ``SLM_RANKING`` is an explicit operator policy.  In 4.0.5 the absence of
    that policy is deliberately ``off``: old learning signals must not begin
    altering recall merely because a user upgrades.  The legacy disable flags
    remain harmless compatibility inputs, but cannot implicitly enable a
    ranking mode.
    """
    raw = (env.get("SLM_RANKING", "") or "").strip().lower()
    if raw in _RANKING_MODES:
        return raw
    return "off"


def apply_ranking(
    response: "RecallResponse",
    query: str,
    profile_id: str,
    query_id: str,
    *,
    config: Any = None,
    pipeline_version: str = "v2-ensemble",
    record_signals: bool = False,
) -> "RecallResponse":
    """Run the ranking pipeline at the requested version.

    Modes:
      - ``off``: identity — no ranking passes run at all.
      - ``v1``: v3.1 Active-Memory adaptive rerank only.
      - ``v2``: v1 + v3.4.22 lambdarank rerank + signal enqueue.
      - ``v2-ensemble`` (default): v2 + v3.4.22 contextual-bandit ensemble.

    Each underlying pass is already defensive (catches its own exceptions),
    so this wrapper adds an outer try/except to guarantee the caller
    always gets a response back. Previously three separate call sites in
    run_recall chained these; collapsing keeps precedence explicit.
    """
    if pipeline_version == "off":
        return response
    try:
        response = apply_adaptive_ranking(response, query, profile_id,
                                          config=config)
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("apply_ranking v1 step skipped: %s", exc)
    if pipeline_version == "v1":
        return response
    try:
        response = apply_v2_adaptive_ranking(
            response, query, profile_id, query_id,
        )
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("apply_ranking v2 step skipped: %s", exc)
    if pipeline_version == "v2":
        return response
    try:
        response = apply_v2_bandit_ensemble(
            response, query, profile_id, query_id,
            record_signals=record_signals,
        )
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("apply_ranking ensemble step skipped: %s", exc)
    return response


# ---------------------------------------------------------------------------
# apply_adaptive_ranking  (was MemoryEngine._apply_adaptive_ranking)
# ---------------------------------------------------------------------------

def apply_adaptive_ranking(
    response: RecallResponse,
    query: str,
    pid: str,
    *,
    config: SLMConfig,
) -> RecallResponse:
    """Apply adaptive re-ranking if enough learning signals exist.

    Phase 1 (< 50 signals): returns response unchanged (backward compat).
    Phase 2 (50+): heuristic boosts from recency, access count, trust.
    Phase 3 (200+): LightGBM ML-based reranking.
    """
    from superlocalmemory.infra.data_root import state_path
    learning_db = state_path("learning.db")
    if not learning_db.exists():
        return response

    # issue #106: count the CANONICAL store, not the legacy one. The
    # dashboard's Living Brain panel and ranker-phase card both resolve their
    # phase from ``learning_signals``; this gate read ``learning_feedback``,
    # so the phase a user was shown and the phase that actually ranked their
    # results were computed from different tables and could disagree without
    # limit. ``learning_feedback`` rows reach this counter through
    # ``legacy_migration``, which copies them forward.
    try:
        signal_count = _ReadOnlyLearningView(learning_db).count_signals(pid)
    except sqlite3.Error:
        # A pre-learning database may not have this optional table yet.
        # Recall remains a query and cannot create it on demand.
        return response

    from superlocalmemory.learning.ranker import (
        PHASE_2_THRESHOLD,
        AdaptiveRanker,
    )

    # Thresholds come from ``learning.ranker`` — the same constants the
    # dashboard gates on. Duplicating the literals here is how the two
    # surfaces drifted apart in the first place.
    if signal_count < PHASE_2_THRESHOLD:
        return response  # Phase 1: no change

    ranker = AdaptiveRanker(signal_count=signal_count)

    from datetime import UTC
    from datetime import datetime as _dt
    _now = _dt.now(UTC)

    result_dicts = []
    for r in response.results:
        _age = 0.0
        _created = getattr(r.fact, "created_at", None)
        if _created:
            try:
                _age = max(0.0, (_now - _dt.fromisoformat(
                    _created.replace("Z", "+00:00")
                )).total_seconds() / 86400.0)
            except (ValueError, TypeError):
                pass
        result_dicts.append({
            "score": r.score,
            "cross_encoder_score": r.score,
            "trust_score": r.trust_score,
            "channel_scores": r.channel_scores or {},
            "fact": {
                "age_days": _age,
                "access_count": r.fact.access_count,
            },
            "_original": r,
        })

    query_context = {"query_type": response.query_type}
    reranked = ranker.rerank(result_dicts, query_context)

    # Rebuild response with new ordering
    for item in reranked:
        original = item.get("_original")
        if original is not None and item.get("_adaptive_score") is not None:
            original.ranking_score = float(item["_adaptive_score"])
    new_results = [d["_original"] for d in reranked]

    return RecallResponse(
        query=response.query,
        mode=response.mode,
        results=new_results,
        query_type=response.query_type,
        channel_weights=response.channel_weights,
        total_candidates=response.total_candidates,
        retrieval_time_ms=response.retrieval_time_ms,
        # v3.6.6: preserve evidence-floor signal across reranking rebuilds.
        no_confident_match=(len(new_results) == 0) and response.no_confident_match,
    )


# ---------------------------------------------------------------------------
# apply_v2_adaptive_ranking (LLD-02 §4.3)
# ---------------------------------------------------------------------------
#
# Opt-in v3.4.22 path: load active model from learning.db with SHA-256
# verification, re-rank via native Booster, enqueue signals async. The
# existing ``apply_adaptive_ranking`` above stays for 3.4.20 callers.
# ---------------------------------------------------------------------------


def apply_v2_adaptive_ranking(
    response: RecallResponse,
    query: str,
    profile_id: str,
    query_id: str,
    *,
    learning_db_path: Any = None,
) -> RecallResponse:
    """LLD-02 §4.3 — load verified model, rerank, enqueue signals.

    Never raises. On any error, returns ``response`` unchanged.
    """
    try:
        from pathlib import Path as _P

        from superlocalmemory.infra.data_root import state_path
        from superlocalmemory.learning.model_cache import load_active
        from superlocalmemory.learning.ranker import AdaptiveRanker

        db_path = (_P(learning_db_path) if learning_db_path
                   else state_path("learning.db"))
        if not db_path.exists():
            return response

        db = _ReadOnlyLearningView(db_path)
        signal_count = db.count_signals(profile_id)
        active = load_active(db, profile_id)

        ranker = AdaptiveRanker(
            signal_count=signal_count,
            active_model=active,
        )

        # Build result-dict shape expected by the ranker's rerank() path.
        from datetime import UTC
        from datetime import datetime as _dt
        _now_v2 = _dt.now(UTC)

        result_dicts: list[dict] = []
        for r in response.results:
            _age_v2 = 0.0
            _created_v2 = getattr(r.fact, "created_at", None)
            if _created_v2:
                try:
                    _age_v2 = max(0.0, (_now_v2 - _dt.fromisoformat(
                        _created_v2.replace("Z", "+00:00")
                    )).total_seconds() / 86400.0)
                except (ValueError, TypeError):
                    pass
            result_dicts.append({
                "fact_id": r.fact.fact_id,
                "score": r.score,
                "cross_encoder_score": r.score,
                "trust_score": r.trust_score,
                "channel_scores": r.channel_scores or {},
                "fact": {
                    "age_days": _age_v2,
                    "access_count": r.fact.access_count,
                },
                "_original": r,
            })

        query_context = {
            "query_type": response.query_type,
            "profile_id": profile_id,
        }
        reranked_dicts = ranker.rerank(result_dicts, query_context)
        for item in reranked_dicts:
            original = item.get("_original")
            if original is not None and item.get("_adaptive_score") is not None:
                original.ranking_score = float(item["_adaptive_score"])
        new_results = [d["_original"] for d in reranked_dicts
                       if "_original" in d]

        # S8-SK-04 fix: signal enqueue is OWNED by ``apply_v2_bandit_ensemble``
        # (see below), not this function. Previously both emitted a batch
        # under the same query_id which doubled ``learning_signals`` and
        # tripped the phase-transition threshold at half the intended
        # signal count. This function now just re-ranks; the ensemble path
        # is the single source of signal events.

        return RecallResponse(
            query=response.query,
            mode=response.mode,
            results=new_results,
            query_type=response.query_type,
            channel_weights=response.channel_weights,
            total_candidates=response.total_candidates,
            retrieval_time_ms=response.retrieval_time_ms,
            # v3.6.6: preserve evidence-floor signal across reranking rebuilds.
            no_confident_match=(len(new_results) == 0) and response.no_confident_match,
        )
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("apply_v2_adaptive_ranking skipped: %s", exc)
        return response


# ---------------------------------------------------------------------------
# apply_v2_bandit_ensemble (LLD-03 §5.5)
# ---------------------------------------------------------------------------
#
# Contextual Thompson bandit chooses channel weights. If an LGBM model is
# active, a D8-blended ensemble re-ranks the reweighted candidates. Never
# raises; honours ``SLM_BANDIT_DISABLED=1`` as a kill switch.
# ---------------------------------------------------------------------------


def apply_v2_bandit_ensemble(
    response: RecallResponse,
    query: str,
    profile_id: str,
    query_id: str,
    *,
    learning_db_path: Any = None,
    record_signals: bool = False,
) -> RecallResponse:
    """Apply contextual bandit + optional LGBM ensemble rerank. Safe on error."""
    import os as _os

    if _os.environ.get("SLM_BANDIT_DISABLED", "0") == "1":
        return response
    if not response.results:
        return response

    try:
        from pathlib import Path as _P

        from superlocalmemory.infra.data_root import state_path
        from superlocalmemory.learning.bandit import ContextualBandit
        from superlocalmemory.learning.ensemble import (
            choose_ensemble,
            ensemble_rerank,
        )
        from superlocalmemory.learning.signals import (
            SignalBatch,
            SignalCandidate,
            enqueue,
        )
        from superlocalmemory.retrieval.engine import apply_channel_weights

        db_path = (_P(learning_db_path) if learning_db_path
                   else state_path("learning.db"))
        if not db_path.exists():
            return response

        # --- 1. bandit.choose ---------------------------------------------
        entity_count = 0
        # Use query_context hints if available on the engine — cheap fallback.
        bandit = ContextualBandit(db_path, profile_id)
        context = {
            "query_type": response.query_type,
            "entity_count": entity_count,
        }
        choice = (
            bandit.choose(context, query_id)
            if record_signals
            else bandit.choose_readonly(context)
        )

        # --- 2. apply channel weights -------------------------------------
        weighted = apply_channel_weights(list(response.results), choice.weights)

        # --- 3. choose ensemble + load model (optional) -------------------
        active_model = None
        signal_count = 0
        try:
            from superlocalmemory.learning.model_cache import load_active
            db = _ReadOnlyLearningView(db_path)
            signal_count = db.count_signals(profile_id)
            active_model = load_active(db, profile_id)
        except Exception as exc:
            logger.debug("v2 bandit: model/signal load skipped: %s", exc)

        weights = choose_ensemble(signal_count, active_model)

        # --- 4. ensemble rerank -------------------------------------------
        query_context = {
            "query_type": response.query_type,
            "profile_id": profile_id,
            "query_id": query_id,
            "bandit_play_id": choice.play_id,
        }
        try:
            final_results = ensemble_rerank(
                weighted, choice, active_model, weights, query_context,
            )
        except Exception as exc:
            logger.debug("v2 bandit ensemble_rerank skipped: %s", exc)
            final_results = weighted

        # Recall is a query.  Implicit learning signals are deliberately
        # disabled on this path: even a non-blocking enqueue eventually writes
        # canonical/learning state and turns dashboard polling into contention.
        # An explicit feedback command owns durable learning signals instead.
        if record_signals:
            try:
                top20 = final_results[:20]
                candidates = tuple(
                    SignalCandidate(
                        fact_id=r.fact.fact_id,
                        channel_scores=dict(r.channel_scores or {}),
                        cross_encoder_score=None,
                        result_dict={"fact_id": r.fact.fact_id,
                                     "score": r.score},
                    )
                    for r in top20
                )
                enqueue(SignalBatch(
                    profile_id=profile_id,
                    query_id=query_id,
                    query_text=query,
                    candidates=candidates,
                    query_context=query_context,
                ))
            except Exception as exc:
                logger.debug("v2 bandit signal enqueue skipped: %s", exc)

        return RecallResponse(
            query=response.query,
            mode=response.mode,
            results=final_results,
            query_type=response.query_type,
            channel_weights=response.channel_weights,
            total_candidates=response.total_candidates,
            retrieval_time_ms=response.retrieval_time_ms,
            # v3.6.6: preserve evidence-floor signal across ensemble rebuilds.
            no_confident_match=(len(final_results) == 0) and response.no_confident_match,
        )
    except Exception as exc:  # pragma: no cover — defensive top-level
        logger.debug("apply_v2_bandit_ensemble skipped: %s", exc)
        return response


# ---------------------------------------------------------------------------
# run_recall  (was MemoryEngine.recall)
# ---------------------------------------------------------------------------

def resolve_hot_path_fast(fast: bool | None, config: "SLMConfig") -> bool:
    """Resolve the recall ``fast`` flag when a caller leaves it unset (None).

    v3.8.2 client-driven agentic: the agent hot path (CLI / MCP / plugins) is
    consumed by a frontier LLM (Claude Code, Copilot, Codex, …) that reformulates
    multi-hop / low-confidence queries far better than the local Ollama model.
    So an unset ``fast`` defaults to True — skip the internal agentic round and
    let the calling LLM drive refinement — whenever ``retrieval.client_driven_agentic``
    is on (the ship default). An explicit ``True``/``False`` from the caller
    always wins (the dashboard search path passes ``True`` for a snappy list;
    a no-smart-client deployment can pass ``False``). Env override
    ``SLM_HOT_PATH_INTERNAL_AGENTIC=1`` forces internal-agentic-on globally.

    This is the single resolution point: every recall path (HTTP, MCP, CLI,
    in-process adapter) funnels through ``run_recall`` and calls this, so the
    client-driven default is consistent everywhere by construction.
    """
    if fast is not None:
        return bool(fast)
    import os
    rc = getattr(config, "retrieval", None)
    client_driven = bool(getattr(rc, "client_driven_agentic", True))
    if os.environ.get("SLM_HOT_PATH_INTERNAL_AGENTIC") == "1":
        client_driven = False
    return client_driven


def run_recall(
    query: str,
    profile_id: str,
    mode: Mode | None = None,
    limit: int = 20,
    agent_id: str = "unknown",
    *,
    config: SLMConfig,
    retrieval_engine: Any,
    trust_scorer: Any,
    embedder: Any,
    db: DatabaseManager,
    llm: Any,
    hooks: HookRegistry,
    access_log: Any = None,
    auto_linker: Any = None,
    fast: bool | None = None,
    include_global: bool = False,
    include_shared: bool = False,
    window: str | tuple[str, str] | None = None,
    as_of: str | None = None,
    known_as_of: str | None = None,
    valid_at: str | None = None,
    include_unknown: bool = False,
) -> RecallResponse:
    """Recall relevant facts for a query.

    Multi-scope: ``include_global`` / ``include_shared`` control which
    scopes participate in retrieval (passed through to retrieval engine).

    Pipeline: retrieval -> agentic sufficiency (if configured) -> post-recall updates.

    ``fast=True`` skips the internal agentic verification round while retaining
    the six local retrieval channels + reranker. ``fast=None`` (unset) resolves
    to the client-driven-agentic default (see ``resolve_hot_path_fast``): the
    agent hot path skips the internal round and delegates refinement to the
    calling LLM. ``fast=False`` forces the internal agentic round.

    ``as_of``: Optional ISO 8601 datetime string for point-in-time time-travel
    recall. When set, the bi-temporal validity filter demotes facts that were
    not yet valid or had already expired at that point. Default ``None`` leaves
    all existing behaviour unchanged.
    """
    m = mode or config.mode

    # v3.8.2: resolve the client-driven-agentic default when a caller left
    # ``fast`` unset (None). After this line ``fast`` is a concrete bool, so
    # the agentic gate below (``if not fast``) behaves identically for every
    # entry point that funnels through here.
    fast = resolve_hot_path_fast(fast, config)

    # v3.5.0 diagnostic: per-stage recall timing under SLM_RECALL_TIMING=1.
    # Zero overhead when the env var is unset. Permanent observability hook.
    import os as _os_t
    import time as _time_t
    _timing = bool(_os_t.environ.get("SLM_RECALL_TIMING"))
    _t0 = _time_t.monotonic()

    def _mark(_label: str) -> None:
        if _timing:
            logger.warning("[RECALL-TIMING] %-22s %.0f ms",
                           _label, (_time_t.monotonic() - _t0) * 1000.0)

    # The interactive path must retain the complete local retrieval contract.
    # Only agentic verification can invoke an unbounded model round.
    extra_disabled = None
    response = retrieval_engine.recall(
        query, profile_id, m, limit,
        extra_disabled_channels=extra_disabled,
        include_global=include_global,
        include_shared=include_shared,
        window=window,
        as_of=as_of,
        known_as_of=known_as_of,
        valid_at=valid_at,
        include_unknown=include_unknown,
    )
    _mark("retrieval(chan+rerank)")

    _mark("pre-agentic")
    # Agentic sufficiency verification
    # V3.3.19: Only trigger for multi_hop queries in Mode A (rule-based).
    # Single-hop/factual/temporal queries get WORSE with decomposition —
    # sub-query noise dilutes precision. Mode C (LLM) can trigger broadly.
    agentic_rounds = config.retrieval.agentic_max_rounds
    if not fast and agentic_rounds > 0 and response.results:
        max_score = max((r.score for r in response.results), default=0.0)
        has_llm = llm is not None and getattr(llm, "is_available", False)
        should_trigger = (
            response.query_type == "multi_hop"
            or (has_llm and max_score < config.retrieval.agentic_confidence_threshold)
            or (has_llm and len(response.results) < 3)
        )
        if should_trigger:
            try:
                from superlocalmemory.retrieval.agentic import AgenticRetriever
                agentic = AgenticRetriever(
                    confidence_threshold=config.retrieval.agentic_confidence_threshold,
                    db=db,
                )
                enhanced_facts = agentic.retrieve(
                    query=query, profile_id=profile_id,
                    retrieval_engine=retrieval_engine,
                    llm=llm,
                    top_k=limit,
                    query_type=response.query_type,
                )
                # Replace response results with enhanced facts if we got more
                if len(enhanced_facts) > len(response.results):
                    from superlocalmemory.storage.models import RetrievalResult
                    enhanced_results = []
                    for i, f in enumerate(enhanced_facts):
                        # Look up real trust score for agentic results
                        fact_trust = 0.5
                        if trust_scorer:
                            try:
                                fact_trust = trust_scorer.get_fact_trust(
                                    f.fact_id, profile_id,
                                )
                            except Exception:
                                pass
                        enhanced_results.append(RetrievalResult(
                            fact=f, score=1.0 / (i + 1),
                            channel_scores={"agentic": 1.0},
                            confidence=f.confidence,
                            relevance_score=1.0 / (i + 1),
                            ranking_score=None,
                            memory_confidence=f.confidence,
                            evidence_chain=["agentic_round_2"],
                            trust_score=fact_trust,
                        ))
                    response = RecallResponse(
                        query=query, mode=m, results=enhanced_results[:limit],
                        query_type=response.query_type,
                        channel_weights=response.channel_weights,
                        total_candidates=response.total_candidates + len(enhanced_facts),
                        retrieval_time_ms=response.retrieval_time_ms,
                        # v3.6.6: agentic round-2 may add facts; recompute flag.
                        no_confident_match=(len(enhanced_results[:limit]) == 0)
                        and response.no_confident_match,
                    )
            except Exception as exc:
                logger.debug("Agentic sufficiency skipped: %s", exc)

    _mark("agentic")
    # S8-ARC-04 (v3.4.22): unified ranking entry point. Single env-var
    # (SLM_RANKING=off|v1|v2|v2-ensemble) controls the pipeline. Legacy
    # SLM_V2_PIPELINE_DISABLED + SLM_BANDIT_DISABLED still honoured for
    # one-release back-compat. Identity when no active model.
    try:
        import os as _os
        import uuid as _uuid
        query_id = _uuid.uuid4().hex
        mode = _resolve_ranking_mode(_os.environ)
        response = apply_ranking(
            response, query, profile_id, query_id,
            config=config, pipeline_version=mode, record_signals=False,
        )
    except Exception as exc:
        logger.debug("Ranking pipeline skipped: %s", exc)

    _preserve_exact_lexical_evidence(response, query)
    _mark("learning+ranking")
    # Deliberately no trust, Fisher, retention, lifecycle, popularity, or graph
    # mutation here.  Those state transitions require a separately authenticated
    # positive/negative outcome; merely returning a result is an exposure.

    from superlocalmemory.core.score_contract import finalize_score_contract
    finalize_score_contract(response)

    # LLD-00 §3 — stamp HMAC markers on every result so post_tool_outcome_hook
    # can validate fact_ids observed in downstream tool output.
    _apply_markers_to_response(response)

    _mark("TOTAL(fisher+trust+markers)")
    return response
