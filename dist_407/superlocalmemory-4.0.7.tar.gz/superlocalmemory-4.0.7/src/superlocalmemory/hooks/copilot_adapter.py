# Copyright (c) 2026 Varun Pratap Bhardwaj / Qualixar
# Licensed under AGPL-3.0-or-later - see LICENSE file
# Part of SuperLocalMemory v3.4.22 — LLD-05 §6

"""Copilot adapter — writes ``.github/copilot-instructions.md``.

LLD-05 §6. Verified (verification-2026-04-17.md claim 5): plain markdown,
no frontmatter, soft 2 KB / hard 4 KB cap. Adapter is INACTIVE when the
project has no ``.github/`` directory — we do not create it ourselves.

v3.4.23 fix: the SLM-managed content is wrapped in
``<!-- SLM-START -->`` / ``<!-- SLM-END -->`` markers and merged into the
host file rather than overwriting it. ``.github/copilot-instructions.md``
is typically a curated, project-specific document; destructive rewrites
deleted the user's prose.

Hard rules covered here:
  - A1 / A2 / A3 / A7: via ``adapter_base.atomic_write``.
  - A4: soft 2 KB + hard 4 KB cap enforcement on the SLM section.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from superlocalmemory.core.security_primitives import (
    PathTraversalError,
    safe_resolve,
)
from superlocalmemory.hooks.adapter_base import (
    COPILOT_SOFT_BYTES,
    HARD_BYTES_CAP,
    WriteResult,
    atomic_write,
    record_disable,
    truncate_to_cap,
)
from superlocalmemory.hooks.context_payload import (
    VERSION,
    ContextPayload,
    RecallFn,
)
from superlocalmemory.hooks.memory_protocol import (
    SLM_MARKER_END,
    SLM_MARKER_START,
    memory_protocol_markdown,
)
from superlocalmemory.hooks.memory_protocol import (
    strip_slm_block as _strip_existing_block,
)

logger = logging.getLogger(__name__)

NAME = "copilot_project"
TARGET_REL = ".github/copilot-instructions.md"

_BODY_TEMPLATE = (
    "# SLM Runtime Memory Protocol\n\n"
    "_Managed by SuperLocalMemory v{version}. This section contains no recalled memory._\n\n"
    "## Never do\n"
    "- Do not modify files under `.slm/`\n"
    "- Do not commit `*.slm-cache.db`\n\n"
)


def render_copilot(payload: ContextPayload | None = None) -> bytes:
    # Two-stage assembly: format the dynamic header (which contains {}
    # placeholders), then concatenate the static memory-protocol block
    # verbatim. The memory-protocol block legitimately contains literal
    # braces (JSON-shaped argument examples for the agent) which must not
    # be interpreted as format fields.
    header = _BODY_TEMPLATE.format(
        version=payload.version if payload is not None else VERSION,
    )
    return (header + memory_protocol_markdown()).encode("utf-8")


def _wrap_managed(rendered: bytes) -> str:
    """Wrap rendered SLM content in ``<!-- SLM-START -->`` markers."""
    return (
        f"{SLM_MARKER_START}\n"
        "<!-- Managed by SuperLocalMemory. Edits between SLM-START and "
        "SLM-END will be overwritten. -->\n\n"
        f"{rendered.decode('utf-8')}\n"
        f"{SLM_MARKER_END}\n"
    )


class CopilotAdapter:
    """Project-scope Copilot adapter (marker-bounded merge)."""

    def __init__(
        self,
        *,
        base_dir: Path,
        sync_log_db: Path,
        recall_fn: RecallFn,
        profile_id: str = "default",
        soft_cap: int = COPILOT_SOFT_BYTES,
        hard_cap: int = HARD_BYTES_CAP,
    ) -> None:
        self._base_dir = Path(base_dir)
        self._sync_log_db = Path(sync_log_db)
        self._recall_fn = recall_fn
        self._profile_id = profile_id
        self._soft_cap = soft_cap
        self._hard_cap = hard_cap
        self.name = NAME
        self._inactive_until_retry = False

    @property
    def target_path(self) -> Path:
        return safe_resolve(self._base_dir, TARGET_REL)

    def is_active(self) -> bool:
        if os.environ.get("SLM_COPILOT_DISABLED") == "1":
            return False
        if self._inactive_until_retry:
            return False
        if os.environ.get("SLM_COPILOT_FORCE") == "1":
            return True
        # Active iff `.github/` directory already exists in the project.
        github_dir = self._base_dir / ".github"
        return github_dir.is_dir()

    def sync(self) -> bool:
        try:
            resolved = self.target_path
        except PathTraversalError:
            logger.warning("copilot: path-traversal refused")
            self._inactive_until_retry = True
            return False

        # Static protocol is intentionally independent of recalled content.
        rendered = render_copilot()
        if len(rendered) > self._hard_cap:
            rendered = truncate_to_cap(rendered, cap=self._hard_cap)

        # Marker-bounded merge — preserve any user-curated content in the
        # host file. Strip any prior SLM block(s) and re-append a fresh one.
        existing = ""
        if resolved.exists():
            try:
                existing = resolved.read_text(encoding="utf-8")
            except OSError as exc:
                logger.warning(
                    "copilot: cannot read %s: %s", resolved, exc,
                )
                return False

        # Orphaned start marker — refuse to write rather than corrupt.
        if (SLM_MARKER_START in existing
                and SLM_MARKER_END not in existing):
            logger.warning(
                "copilot: %s present but %s missing in %s; refusing to write",
                SLM_MARKER_START, SLM_MARKER_END, resolved,
            )
            return False

        stripped = _strip_existing_block(existing)
        section = _wrap_managed(rendered)
        if stripped:
            if not stripped.endswith("\n"):
                stripped += "\n"
            # One blank line between user content and the managed section.
            new_content = stripped + "\n" + section
        else:
            new_content = section

        result: WriteResult = atomic_write(
            resolved, new_content.encode("utf-8"),
            adapter_name=self.name,
            profile_id=self._profile_id,
            sync_log_db=self._sync_log_db,
        )
        return result.wrote

    def disable(self) -> None:
        try:
            resolved = self.target_path
        except PathTraversalError:
            return
        # Marker-bounded strip — never delete the host file (user-owned).
        if resolved.exists():
            try:
                existing = resolved.read_text(encoding="utf-8")
            except OSError:
                existing = ""
            stripped = _strip_existing_block(existing)
            if stripped != existing:
                try:
                    resolved.write_text(stripped, encoding="utf-8")
                except OSError as exc:  # pragma: no cover
                    logger.warning(
                        "copilot: failed to strip on disable: %s", exc,
                    )
        record_disable(
            resolved,
            adapter_name=self.name,
            profile_id=self._profile_id,
            sync_log_db=self._sync_log_db,
        )
        self._inactive_until_retry = True


__all__ = ("CopilotAdapter", "NAME", "TARGET_REL", "render_copilot")
